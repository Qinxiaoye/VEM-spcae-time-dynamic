function AK = elemK_fem(elemID,node,elem,mat,zline,theta)
% calculate elem stiffness matrix
% for k = 1

index = elem{elemID};

x = node(index ,1); y = node(index ,2);

EX = mat(1); mu = mat(2); rho = mat(3);
h = zline(2)-zline(1);
D = EX/(1-mu^2)*[1,mu,0;mu,1,0;0,0,(1-mu)/2];

Nv = length(x);

Int = zeros(Nv);
nip = 2;
[point,weight] = gaussInt(nip);

% integral
for n = 1:nip
    for m = 1:nip
        f = fun(point(n),point(m),0,2,4);
        [N_ks,N_yt] = dfun2D(point(n),point(m),4);
        J = [N_ks,N_yt]'*[x,y];
        Int = Int+weight(n)*weight(m)*(f*f')*det(J);
    end
end
NN = zeros(2);
NdN = zeros(2);
dNN = zeros(2);
dNdN = zeros(2);
for n = 1:nip
    f = fun(point(n),0,0,1,2);
    df = dzshape(f'*zline',zline(1),zline(2));
    NN = NN+weight(n)*(f*f')*(zline(2)-zline(1))/2;
    NdN = NdN+weight(n)*(f*df)*(zline(2)-zline(1))/2;
    dNN = dNN+weight(n)*(df'*f')*(zline(2)-zline(1))/2;
    dNdN = dNdN+weight(n)*(df'*df)*(zline(2)-zline(1))/2;
end


Kpp = [Int*NN(1,1),Int*NN(1,2);
    Int*NN(2,1),Int*NN(2,2)]+...
    theta*h*[Int*dNN(1,1),Int*dNN(1,2);
    Int*dNN(2,1),Int*dNN(2,2)];
Kpp = blkdiag(Kpp,Kpp);
Kpu = [Int*NdN(1,1),Int*NdN(1,2);
    Int*NdN(2,1),Int*NdN(2,2)]+...
    theta*h*[Int*dNdN(1,1),Int*dNdN(1,2);
    Int*dNdN(2,1),Int*dNdN(2,2)];
Kpu = blkdiag(Kpu,Kpu);
Kup = Kpu;

A1 = [1,0;0,0;0,1];
A2 = [0,0;0,1;1,0];
A = [A1,A2];

int_uu = zeros(8);
for n = 1:nip
    for m = 1:nip
        [N_ks,N_yt] = dfun2D(point(n),point(m),4);
        dN = [N_ks,N_yt]';
        J = dN*[x,y];
        dN = J\dN;
        dN = blkdiag(dN,dN);
        int_uu = int_uu+weight(n)*weight(m)*dN'*A'*D*A*dN*det(J);
    end
end

int_uu11 = int_uu(1:Nv,1:Nv);
int_uu12 = int_uu(1:Nv,Nv+1:2*Nv);
int_uu21 = int_uu(Nv+1:2*Nv,1:Nv);
int_uu22 = int_uu(Nv+1:2*Nv,Nv+1:2*Nv);

Kuu = [NN(1,1)*int_uu11,NN(2,1)*int_uu11,NN(1,1)*int_uu12,NN(2,1)*int_uu12;
    NN(1,2)*int_uu11,NN(2,2)*int_uu11,NN(1,2)*int_uu12,NN(2,2)*int_uu12;
    NN(1,1)*int_uu21,NN(2,1)*int_uu21,NN(1,1)*int_uu22,NN(2,1)*int_uu22;
    NN(1,2)*int_uu21,NN(2,2)*int_uu21,NN(1,2)*int_uu22,NN(2,2)*int_uu22]+...
    theta*h*[dNN(1,1)*int_uu11,dNN(1,2)*int_uu11,dNN(1,1)*int_uu12,dNN(1,2)*int_uu12;
            dNN(2,1)*int_uu11,dNN(2,2)*int_uu11,dNN(2,1)*int_uu12,dNN(2,2)*int_uu12;
            dNN(1,1)*int_uu21,dNN(1,2)*int_uu21,dNN(1,1)*int_uu22,dNN(1,2)*int_uu22;
            dNN(2,1)*int_uu21,dNN(2,2)*int_uu21,dNN(2,1)*int_uu22,dNN(2,2)*int_uu22];


AK = [-1/rho*Kpp,Kpu;Kup,Kuu];


function df = dzshape(t,t1,t2)

df1 = -1/(t2-t1);
df2 = 1/(t2-t1);

df = [df1,df2];

