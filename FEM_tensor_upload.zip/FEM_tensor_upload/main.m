clear;
zline = 0:0.1:10;
load quad.mat;
[node3,elem3] = PolyMesh3Simple(node,elem,zline);

k = 1; % order, cannot be changed
ndim = 2;
theta = 0.01;
tic
sumNode = size(node,1);
mat = [200000,0.3,10]; % E,nu,rho
% global stiffness matrix

[GK] = globalK(node,elem,mat,zline,theta);


leftNode = find(node3(:,1)<0.01);
bottomNode = find(node3(:,3)<0.01);

loadNode = find(node(:,1)>4.99);
pface = findFace(node,elem,loadNode);
p = -100;
press = [pface,ones(length(pface),1)*p];

f = getForce(node,sumNode,size(node3,1),elem,1,press,zline,'y',theta);



% rightNode = find(node3(:,1)>9.99);



NsumNode = size(GK,1)/4;

% 
[GK,f] = boudnaryCondition(GK,[leftNode;bottomNode],f,NsumNode);


u = GK\f;
u = full(u);

toc;

dispNode = 26:sumNode:size(node3,1);

u = u(NsumNode*2+1:end);
u = reshape(u,[],2);
node3New = node3;
node3New(:,1:2) = node3New(:,1:2)+u;
figure;
showsolution3D(node3New(:,[1,3,2]),elem3,u(:,2))
figure;
plot(zline,u(dispNode,2));


