function [GK] = globalK(node,elem,mat,zline,theta)
% calculate the global stiffness matrix
% output: GK


sumElem = size(elem,1); % the number of element
sumNode = size(node,1);


elemLen = cellfun('length',elem);
elemLenNew = repmat(elemLen*2,1,length(zline)-1)';
elemLen = elemLenNew(:);
nnz = sum((elemLen*4).^2);
NsumNode = sumNode*length(zline);


ii = zeros(nnz,1); jj = zeros(nnz,1); ss = zeros(nnz,1); 


ia = 0;
for n = 1:sumElem
    for m = 1:(length(zline)-1)
        AK = elemK_fem(n,node,elem,mat,[zline(m),zline(m+1)],theta);
        AB = reshape(AK,1,[]); 
        index = [elem{n}+sumNode*(m-1),elem{n}+sumNode*m];
        Nv = length(index);
        elemDof = [index, index+NsumNode, index+NsumNode*2, index+NsumNode*3];
        % --------- assembly index for ellptic projection -----------
        indexDof = elemDof;  Ndof = Nv*4;  % local to global index
        ii(ia+1:ia+Ndof^2) = repmat(indexDof(:), Ndof, 1);
        jj(ia+1:ia+Ndof^2) = reshape(repmat(indexDof, Ndof, 1), [], 1);
        ss(ia+1:ia+Ndof^2) = AB(:);
        ia = ia + Ndof^2;
    end
end

GK = sparse(ii,jj,ss,NsumNode*4,NsumNode*4);